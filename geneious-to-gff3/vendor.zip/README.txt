Flask and the packages it needs, bundled here so that the tool runs without installing anything,
and kept inside this single zip file so that Windows' 260-character path limit cannot truncate them
when the tool folder sits deep inside other folders. Python imports packages from a zip directly.

Unmodified code from the official wheels on PyPI (https://pypi.org), each under its own license
(BSD-3-Clause or MIT; see the licenses folder inside this zip, and LICENSES_bundled.txt next to app.py):

  flask 3.1.3, werkzeug 3.1.7, jinja2 3.1.6, markupsafe 3.0.3 (pure-Python part only),
  itsdangerous 2.2.0, click 8.1.8, blinker 1.9.0, colorama 0.4.6 (without its tests)

One addition: an empty flask/sansio/__init__.py. Flask ships that folder without one, relying on
implicit namespace packages, which Python does not support inside a zip. The file is empty and
changes no behaviour.

These versions work with Python 3.9 and newer. app.py puts this zip at the front of Python's search
path, so a Flask installed elsewhere on the computer is not used and cannot interfere.
